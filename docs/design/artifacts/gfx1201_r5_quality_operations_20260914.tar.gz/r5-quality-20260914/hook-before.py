# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Run a benchmark-only R5 continuation attention hook.

This module is injected with ``PYTHONPATH`` into an isolated model process. It
does not edit or register a production backend.  Only
``TurboQuantAttentionImpl._continuation_prefill`` calls with
``cached_len > 0`` and ``q_len > 128`` temporarily route their existing
materialization through the loaded AMD Triton FlashAttention function. All
other calls invoke the original method unchanged.
"""

from __future__ import annotations

import json
import atexit
import os
import threading
from pathlib import Path
from typing import Any

import flash_attn
from vllm.model_executor.warmup import kernel_warmup
from vllm.v1.worker.gpu import warmup

from vllm.v1.attention.backends import turboquant_attn
from vllm.v1.attention.backends.turboquant_attn import TurboQuantAttentionImpl

_ORIGINAL = TurboQuantAttentionImpl._continuation_prefill
# Match the previously validated diagnostic Math baseline in both arms.
warmup.warmup_kernels = lambda *args, **kwargs: None
kernel_warmup.kernel_warmup = lambda *args, **kwargs: None
turboquant_attn._HAS_FLASH_ATTN = False
_LOCK = threading.Lock()
_COUNTS: dict[str, Any] = {
    "enabled": os.environ.get("R5_MODE") == "candidate",
    "calls": 0,
    "shapes": {},
    "restored_globals": True,
}


def _record(cached_len: int, q_len: int) -> None:
    with _LOCK:
        _COUNTS["calls"] += 1
        key = f"cached{cached_len}_q{q_len}"
        shapes = _COUNTS["shapes"]
        shapes[key] = int(shapes.get(key, 0)) + 1


def _patched(self: TurboQuantAttentionImpl, *args: Any, **kwargs: Any):
    query = kwargs.get("query", args[1] if len(args) > 1 else None)
    cached_len = kwargs.get("cached_len", args[6] if len(args) > 6 else None)
    q_len = int(query.shape[0]) if query is not None else 0
    cached_len = int(cached_len) if cached_len is not None else 0
    layer = kwargs.get("layer", args[0] if args else None)
    layer_name = getattr(layer, "layer_name", "")
    target = layer_name.startswith("model.layers.")
    if not _COUNTS["enabled"] or not target or cached_len <= 0 or q_len <= 128:
        return _ORIGINAL(self, *args, **kwargs)

    _record(cached_len, q_len)
    _write_stats()
    old_has = turboquant_attn._HAS_FLASH_ATTN
    old_func = getattr(turboquant_attn, "flash_attn_varlen_func", None)
    turboquant_attn._HAS_FLASH_ATTN = True
    turboquant_attn.flash_attn_varlen_func = flash_attn.flash_attn_varlen_func
    try:
        return _ORIGINAL(self, *args, **kwargs)
    finally:
        turboquant_attn._HAS_FLASH_ATTN = old_has
        if old_func is None:
            turboquant_attn.__dict__.pop("flash_attn_varlen_func", None)
        else:
            turboquant_attn.flash_attn_varlen_func = old_func


TurboQuantAttentionImpl._continuation_prefill = _patched


def _write_stats() -> None:
    path = os.environ.get("R5_HOOK_STATS")
    if not path:
        return
    Path(path).write_text(json.dumps(_COUNTS, sort_keys=True) + "\n")


atexit.register(_write_stats)
